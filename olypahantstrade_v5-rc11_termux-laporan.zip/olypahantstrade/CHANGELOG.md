# Changelog — olypahantstrade

Nama proyek: **olypahantstrade**. Nama paket Python (`btc_robot`) sengaja tidak diubah agar impor/perintah/tes tetap sama.

## 0.3.4 (laporan otomatis .txt untuk Termux)
- `scripts/auto_report.py` + `run_termux.sh`: unduh data 4h/1d bila belum ada, backtest spot & futures, tulis `docs/swing/REPORT_terbaru.txt` (salinan bertanggal; disalin ke ~/storage/downloads di Termux). Ada saringan awal kasar per koin/pasar; bukan gerbang G0-G8.

## 0.3.4 (laporan .txt otomatis untuk Termux)
- `scripts/laporan_txt.py` + `jalankan.sh`: unduh data BTC/BNB/SOL 4h+1d (jika belum ada), backtest spot dan futures, tulis `laporan/laporan_*.txt` (+ salinan ke ~/storage/downloads). Saringan: trx>=30, PF>=1.2, DD<=15%, WF>=3/4, return>0 (bukan gerbang G0-G8).

## 0.3.3 (strategi D1+H4 digabung ke robot)
- Mode baru `d1h4_spot` (long-only) dan `d1h4_futures` (long+short sweep) pada interval 4h; D1 dibangun dari 6 candle 4H lengkap, dipakai hanya setelah tutup (tanpa lookahead). Kode: `btc_robot/strategy_d1h4.py`.
- `config.spot_4h` dan `config.futures_4h` kini memakai mode ini; 1d tetap `lab_trend`. Ukuran posisi 1%, tanpa leverage, cooldown, dan gerbang LIVE tetap dari RiskEngine (tidak ada jalur order baru).
- Spot: stop = swing low D1 x 0.98, tanpa TP, keluar via trailing 8% (menggantikan exit 'D1 EMA21 / RSI>70' di komentar asli). Futures: stop 0.3% di luar sumbu, TP 2R, batas tahan 10 hari.
- Tes baru `tests/test_d1h4.py` (setup, kausalitas, sisi, guard config). Hasil masih SINTETIS; adapter CCXT belum dipasang (LIVE tetap terkunci).

## 0.3.2 (swing 4h/1d: spot + futures)
- 4 config contoh: `config.spot_4h/spot_1d` (long-only) dan `config.futures_4h/futures_1d` (long+short, TANPA leverage); strategi `lab_trend`.
- Tahan lama: `max_hold_sec=0`; keluar lewat stop awal 2.5 ATR lalu trailing (4h 5%, 1d 8%, aktif setelah laba 3%). Risiko 1%/transaksi, DD maks 15%.
- `scripts/swing_report.py`: spot vs futures per simbol/TF, funding dipotong pasca-hoc (mesin belum memodelkan funding/likuidasi).
- `tests/test_swing_configs.py`. Semua hasil masih data SINTETIS; gerbang G0-G8 belum lulus; LIVE tetap terkunci.

## v0.3.0 (kandidat v5: menunggu audit independen)
Menindaklanjuti "Permintaan Perbaikan dan Audit Bersama". Rincian: `docs/AUDIT_V5.md`. Tidak ada gerbang yang dinyatakan lulus.

**Bug/celah nyata yang ditemukan dan diperbaiki (semua dapat direproduksi terhadap v4: `scripts/repro_v4_bugs.py`)**
- M1/H1 saling memuat dan menimpa state bila `state_dir` sama (M1 melapor `ok`) → `identity.json` + penolakan aman + state_dir terpisah + kill switch bersama.
- Urutan jalur order: SafeGuard sebelum Risk dan tanpa HALT final → `HALT → Risk → SafeGuard → Portofolio → HALT final → eksekusi`.
- Cooldown breaker dimulai malas (bergantung pada sinyal yang dievaluasi) → dimulai saat rugi ke-3 ditutup. **Mengubah hasil MTF** (+10,1998% → +10,2189%); H1/M1 identik.
- `statemachine.py` tidak dipakai engine → terhubung, dipersist, diverifikasi konsisten; transisi ilegal ⇒ HALT.
- Token Telegram di dalam teks error lolos redaksi audit; placeholder `PUT_NEW_TOKEN_HERE` dipakai sebagai token; `fetch_binance_klines` membocorkan `TypeError`.
- Dashboard: `step` memanggil `now_ms()` sebelum mengambil data (500 pada mode demo/manual) — ditemukan oleh tes script halaman.

**Fitur**
- `dashboard` (loopback, token, ACC tanpa order, AI Scan/Manual, M1/H1 terpisah, status HALT/Safe Guard); `scripts/verify_live_data.py`; `scripts/analyze_m1.py`; `scripts/gate_evidence.py` (matriks G0–G8, inventaris tes); `scripts/package_check.py`; `config_warnings` (peringatan statis biaya vs stop/trailing).
- Walk-forward melaporkan `total_fees`, `net_pnl`, `win_rate` per jendela.

**M1:** tidak ada perubahan parameter (tidak ada dukungan data). Status M1 dan H1: BELUM LULUS (lihat `docs/M1_H1_REPORT.md`).

## v0.2.0 (v4 paket)
Menindaklanjuti laporan review lima butir (mode H1/M1, integrasi Safeguard, scanner multi-koin dan risiko bersama,
HALT/recovery, bukti kelulusan). Semua tes lolos (lihat `docs/GATE_EVIDENCE.md` untuk jumlah terkini).

**Bug nyata yang ditemukan dan diperbaiki oleh tes kegagalan**
- `recover-halt` tidak melihat latch HALT safeguard (berkas terpisah): robot halt tetapi `diagnose` melapor "tidak halted"
  dan pemulihan ditolak (buntu). Kini kedua sumber dilihat; `release_halt()` tidak mereset loss streak/cooldown.
- Crash saat commit `paper_state.json` setelah `safeguard_state.json` tersimpan membuat langkah yang diulang menghitung
  loss streak DUA kali (4 dari 299 skenario crash menyimpang). Kini `record_closed_trade(pnl, closed_ts)` idempoten (0 dari 299).
- `paper_step` crash dengan traceback bila sumber data melempar error selain `DataError`; kini status `no_data`, state utuh.
- State paper yang rusak/tidak valid: ditolak (`state_corrupt`), berkas tidak ditimpa.
- Error eksekusi tak terduga saat submit order kini HALT (`exec_unknown`), bukan crash dan bukan retry buta.

**Fitur**
- Mode mandiri `h1_trend` (1h) dan `m1_scalp` (1m) + config contoh; validasi interval per mode; pabrik `strategies.make_strategy`.
- Spread order book terhubung ke engine (PAPER, `fetch_book_ticker`); max-hold dan trailing stop terhubung ke penutupan
  posisi; filter edge-vs-biaya di RiskEngine; batas entry per jam bisa diatur. Semua nonaktif secara default
  (hasil backtest mode lama IDENTIK; hash MTF `739d19906c93` tidak berubah).
- `Engine` dipecah `begin_bar`/`end_bar` (OPEN/CLOSE) agar simulasi lintas-interval kausal.
- `portfolio.py`: scanner (manual/auto), `PortfolioRiskGate`, `run_portfolio_backtest`; CLI `portfolio-backtest` dan `scan`.
- `scripts/gate_evidence.py` membuat `docs/GATE_EVIDENCE.md` (bukti per modul dari impor nyata + status G0-G8).

**Temuan penting (jujur)**
- Gerbang G0-G8 TETAP belum lulus. StateMachine belum terhubung ke engine; tidak ada adapter order bursa; belum ada
  runner PAPER portofolio; semua hasil strategi masih dari data SINTETIS.
- Max-hold 90 detik tidak bisa ditegakkan dengan candle 1m (granularitas 1 candle).

## v0.1.1 (v3 paket)
Hasil code review + uji. Semua 82 tes lolos (73 lama + 9 baru di `tests/test_fixes_v011.py`).

- **Performa MTF**: `_latest_closed` kini memakai bisect (O(log n)). Sebelumnya kuadratik: 40 ribu candle ~48 dtk,
  data 3 tahun ~9 menit; sekarang 40 ribu candle ~2 dtk. `result_hash` identik dengan versi lama pada config yang sama.
- **Circuit breaker efektif**: cooldown 300 dtk < candle 15m membuat breaker nyaris tak berfungsi (hanya 1 sinyal terlewat).
  Kini `risk.max_loss_streak` (default 3) dan `risk.loss_streak_cooldown_sec` (default 14400 = 4 jam) bisa diatur di config;
  validasi menolak cooldown lebih pendek dari satu candle. PERHATIAN: ini mengubah hasil backtest (lebih sedikit trade).
- **Celah data di paper**: jika candle antara `last_ts` dan awal jendela terlewat (cron mati > ~125 jam):
  dengan posisi terbuka -> HALT latch (pulihkan dengan `recover-halt` setelah ditinjau manusia);
  tanpa posisi -> sinyal lama dibuang, dicatat di audit (`data_gap_skipped`), trading lanjut.
  Hasil `paper-step` kini memuat `gap_missed_bars`.
- **Warm-up walk-forward otomatis**: `walk_forward(warmup_bars=None)` memakai `required_warmup(cfg)`
  (MTF butuh >= 202 candle 15m; default lama 120 terlalu pendek).
- **File lock** pada `paper-step` (`state/.paper.lock`): eksekusi yang tumpang tindih mengembalikan `status: locked`.
- **`.env`** juga dicari di folder proyek, bukan hanya folder kerja (cron dari folder lain).
- Skrip bantu baru di `scripts/`: `download_btc_history.py` (unduh klines Binance 3 tahun -> CSV) dan
  `run_paper_24h.sh` (paper trading 24 jam tiap candle 15m).

### Belum diubah (keputusan desain)
- Batas drawdown & rugi harian hanya dievaluasi saat ada sinyal baru, dan rugi harian hanya yang terealisasi.
- `holdout` mengevaluasi 20% data terakhir tanpa warm-up tambahan.
- Hasil simulasi bukan bukti profitabilitas; semua gerbang G0–G8 harus lulus sebelum LIVE.

## 0.3.1 (lab M15)
- Mode M15: `config.m15.example.json` (interval 15m, strategy_mode lab_pullback). M1 tidak dihapus.
- 4 strategi baru parameter tetap: lab_pullback, lab_fib (Fibonacci 0.382-0.618), lab_donchian, lab_bbrev.
- `scripts/fetch_all.py` (unduh BTC/BNB/SOL 15m+1h) dan `scripts/strategy_lab.py` (backtest + walk-forward semua strategi).
- Belum diuji pada data pasar nyata; hasil sintetis TIDAK bermakna untuk profit.
