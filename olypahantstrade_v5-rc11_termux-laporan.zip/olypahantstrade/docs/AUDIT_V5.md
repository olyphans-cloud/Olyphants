# Laporan audit v4 → v0.3.0 (kandidat rilis v5)

Status keseluruhan: **kandidat, belum dinyatakan lulus.** Sesuai aturan proyek, ZIP ini harus diaudit ulang secara independen
oleh ChatGPT dan disetujui pengguna. Tidak ada gerbang G0–G8 yang berstatus LULUS (lihat `GATE_MATRIX.md`).

Bukti yang dapat dijalankan ulang oleh siapa pun: `python3 scripts/repro_v4_bugs.py <pohon_kode>` (hasil terlampir:
`docs/m1_audit/repro_v4.txt` untuk v4 dan `repro_v5.txt` untuk kode ini), `python3 -m unittest discover -s tests -t .`, dan
`python3 scripts/gate_evidence.py`.

## 1. Temuan, perbaikan, dan bukti

| # | Prioritas | Temuan pada v4 | Bukti sebelum | Perbaikan | Bukti sesudah |
|---|---|---|---|---|---|
| 1 | B | M1/H1 memakai nama berkas state tetap di satu `state_dir`; tidak ada identitas. M1 yang dijalankan di atas state H1 melapor `status: ok` dan menulis ulang state. | repro #1 = ADA | `identity.json` per state_dir, penolakan aman tanpa menulis apa pun, state lama butuh `adopt-state --confirm-identity`, state_dir terpisah per mode, kill switch bersama | repro #1 = TIDAK; `test_v030_isolation` (17 tes, termasuk thread paralel & restart) |
| 2 | C | SafeGuard dipanggil **sebelum** Risk Engine; tidak ada pemeriksaan HALT tepat sebelum submit | repro #2, #5 = ADA | Pipeline eksplisit `HALT → Risk → SafeGuard → Portofolio → HALT final → eksekusi` (`engine.PIPELINE`) | repro #2, #5 = TIDAK; `PipelineOrderTests` (8 tes urutan/veto/race) |
| 3 | C | Cooldown breaker dimulai **malas** pada sinyal berikutnya yang kebetulan dievaluasi, sehingga waktunya bergantung pada urutan pemeriksaan | repro #3 = ADA | Cooldown dimulai saat rugi ke-3 ditutup (`record_closed_trade(..., cooldown_anchor_ms)`) | repro #3 = TIDAK; `CooldownAnchoringTests` (3 tes) |
| 4 | C | `statemachine.py` hanya "ada file + tes unit"; engine tidak memakainya | repro #4 = ADA | Engine menggerakkan state machine pada jalur entry/exit; state dipersist dan diverifikasi konsisten dengan ledger; transisi ilegal ⇒ HALT; order status tak diketahui ⇒ RECONCILING | repro #4 = TIDAK; `StateMachineIntegrationTests`, `StateMachinePersistenceTests` |
| 5 | E | Redaksi audit hanya berdasarkan **nama kunci**: token Telegram di dalam teks error lolos ke log | repro #6 = ADA | Pola token disensor di dalam string | repro #6 = TIDAK; `SecretHandlingTests` |
| 6 | E | Placeholder `PUT_NEW_TOKEN_HERE` dipakai sebagai token | repro #7 = ADA | Placeholder dianggap belum dikonfigurasi | repro #7 = TIDAK; `TelegramTests` |
| 7 | E | `fetch_binance_klines` membocorkan `TypeError` mentah pada baris `null` | repro #8 = ADA | Bentuk respons divalidasi; semua error ⇒ `DataError` | repro #8 = TIDAK; `FetchFaultTests` (15 skenario) |
| 8 | A/F | Walk-forward tidak melaporkan biaya per jendela | repro #9 = ADA | `total_fees`, `net_pnl`, `win_rate` per jendela | repro #9 = TIDAK |
| 9 | D | Dashboard tidak ada (hanya backend) | - | `btc_robot/dashboard.py` + `python -m btc_robot dashboard` | `test_v030_dashboard` (28 tes). Bug internal ditemukan oleh tes script halaman (`step` memanggil `now_ms()` sebelum data) dan diperbaiki |
| 10 | A | M1 merugi | backtest M1: −7,99%, halt drawdown | **Tidak ada perubahan parameter** (tidak ada dukungan data) — lihat `M1_H1_REPORT.md` | status M1: BELUM LULUS |

Temuan dari iterasi sebelumnya yang tetap diuji ulang: deadlock recovery bila hanya safeguard yang halt, penghitungan ganda loss streak
setelah crash saat simpan (0 dari 299 skenario crash menyimpang), `paper_step` crash bila sumber data melempar error umum.

## 2. M1 (Prioritas 1) — ringkasan; rincian di `docs/M1_H1_REPORT.md`

- **Implementasi M1 lolos audit** (16 tes + mutation check): tanpa look-ahead, timestamp konsisten, biaya dihitung ulang independen cocok, aturan lot benar.
- **Sumber kerugian:** bukan bug. Pada config M1, biaya pulang-pergi (0,18%) ≈ jarak stop rata-rata (0,17%). Dengan RR 3:1 pada pergerakan acak, peluang TP ≈ 25% sedangkan win rate impas ≈ 51%. Laba kotor +17,30 vs biaya 97,23.
- **Entry acak sebagai pembanding:** laba kotor/transaksi M1 hanya di persentil 93 (tidak signifikan).
- **Filter `min_edge_cost_mult` tidak pernah aktif** pada config ini; ablasi `no_edge_filter` = baseline.
- **Walk-forward:** M1 negatif di 4/4 jendela; holdout −4,68%. H1: 3/4 jendela positif; holdout −0,59% (9 transaksi).
- **Klaim "H1 unggul" tidak bisa dipertahankan:** pada regime terkendali H1 negatif di 4/5 regime.
- Angka yang Anda kutip (M1: 22 transaksi −1,95%; H1: 10 transaksi +1,60%) tidak berasal dari run ini dan tidak direproduksi.

## 3. Perbandingan sebelum/sesudah (data, biaya, aturan risiko sama)

H1 dan M1 identik (hash sama). MTF berubah (+10,1998% → +10,2189%; DD 3,31% → 2,83%) karena temuan #3. Tabel: `M1_H1_REPORT.md` bagian 9.

## 4. Batas laporan ini

Semua hasil strategi memakai data **sintetis**; pengambilan data pasar nyata, Telegram sungguhan, dan tampilan browser sungguhan
**tidak dijalankan** (lihat `TEST_INVENTORY.md` bagian "Belum dijalankan" dan `REMAINING_ISSUES.md`).
