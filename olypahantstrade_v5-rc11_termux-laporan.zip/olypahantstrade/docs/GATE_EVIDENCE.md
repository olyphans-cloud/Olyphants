# olypahantstrade — bukti per modul (kode v0.3.0)

Dibuat otomatis oleh `scripts/gate_evidence.py`; jangan disunting tangan.

**Ringkasan tes:** 284 tes, 284 lulus, 0 gagal/error, 0 dilewati.

Kolom 'tes di berkas' = jumlah tes dalam berkas yang mengimpor modul (keterkaitan, bukan jaminan cakupan penuh).

| Modul | Jenis bukti | Berkas tes | Tes di berkas | Gagal | Belum tercakup |
|---|---|---|---|---|---|
| `audit` | integrasi, integrasi/kegagalan data+secret, kegagalan/recovery, unit | test_core, test_paper, test_recovery, test_roadmap_modules, test_v020_failure_recovery, test_v020_portfolio, test_v020_safeguard_wiring, test_v030_data_secrets, test_v030_pipeline | 182 | 0 | - |
| `backtest` | audit implementasi, integrasi, integrasi/kegagalan data+secret, unit | test_core, test_fixes_v011, test_roadmap_modules, test_v020_modes, test_v020_portfolio, test_v030_data_secrets, test_v030_m1_audit | 134 | 0 | Hanya data sintetis; belum ada riwayat nyata multi-tahun di dalam bukti. |
| `config` | audit implementasi, integrasi, integrasi/isolasi, integrasi/kegagalan data+secret, kegagalan/recovery, unit | test_core, test_fixes_v011, test_mtf_strategy, test_paper, test_recovery, test_roadmap_modules, test_v020_failure_recovery, test_v020_modes, test_v020_portfolio, test_v020_safeguard_wiring, test_v030_config_warnings, test_v030_data_secrets, test_v030_isolation, test_v030_m1_audit, test_v030_pipeline | 245 | 0 | - |
| `dashboard` | integrasi/UI-API | test_v030_dashboard | 28 | 0 | Tampilan visual di browser sungguhan BELUM diuji; yang teruji: API HTTP, keamanan, dan script halaman di Node dengan DOM tiruan. |
| `data` | audit implementasi, integrasi, integrasi/UI-API, integrasi/isolasi, integrasi/kegagalan data+secret, kegagalan/recovery, unit | test_core, test_fixes_v011, test_mtf_strategy, test_paper, test_roadmap_modules, test_v020_failure_recovery, test_v020_modes, test_v020_portfolio, test_v020_safeguard_wiring, test_v030_dashboard, test_v030_data_secrets, test_v030_isolation, test_v030_m1_audit, test_v030_pipeline | 264 | 0 | Koneksi nyata ke Binance (klines & bookTicker) belum pernah diuji; hanya server tiruan lokal (15 skenario kegagalan). |
| `engine` | integrasi, integrasi/kegagalan data+secret, kegagalan/recovery | test_v020_failure_recovery, test_v020_portfolio, test_v020_safeguard_wiring, test_v030_data_secrets, test_v030_pipeline | 123 | 0 | Spread saat fill nyata tidak ada di backtest; trailing/max-hold bergranularitas candle, bukan tick. |
| `execution` | audit implementasi, integrasi, integrasi/kegagalan data+secret, kegagalan/recovery, unit | test_core, test_v020_failure_recovery, test_v020_portfolio, test_v020_safeguard_wiring, test_v030_data_secrets, test_v030_m1_audit, test_v030_pipeline | 170 | 0 | Hanya adapter SIMULASI. Tidak ada adapter order bursa; 'status order tidak diketahui' hanya disimulasikan. |
| `gates` | unit | test_core, test_roadmap_modules | 49 | 0 | - |
| `identity` | integrasi/UI-API, integrasi/isolasi, kegagalan/recovery | test_recovery, test_v030_dashboard, test_v030_isolation | 49 | 0 | - |
| `indicators` | unit | test_core | 31 | 0 | - |
| `ledger` | integrasi, integrasi/kegagalan data+secret, kegagalan/recovery, unit | test_core, test_v020_failure_recovery, test_v020_portfolio, test_v020_safeguard_wiring, test_v030_data_secrets, test_v030_pipeline | 154 | 0 | - |
| `models` | audit implementasi, integrasi, integrasi/UI-API, integrasi/isolasi, integrasi/kegagalan data+secret, kegagalan/recovery, unit | test_core, test_fixes_v011, test_mtf_strategy, test_v020_failure_recovery, test_v020_modes, test_v020_portfolio, test_v020_safeguard_wiring, test_v030_dashboard, test_v030_data_secrets, test_v030_isolation, test_v030_m1_audit, test_v030_pipeline | 240 | 0 | - |
| `mtf_strategy` | integrasi, unit | test_fixes_v011, test_mtf_strategy, test_v020_modes | 25 | 0 | Idem: hanya data sintetis. |
| `paper` | integrasi, integrasi/isolasi, integrasi/kegagalan data+secret, kegagalan/recovery | test_fixes_v011, test_paper, test_v020_failure_recovery, test_v030_data_secrets, test_v030_isolation, test_v030_pipeline | 106 | 0 | Runner paper = satu sleeve per proses (state terpisah per mode/koin lewat identitas). Belum ada runner paper portofolio. |
| `portfolio` | integrasi, integrasi/UI-API | test_v020_portfolio, test_v030_dashboard | 51 | 0 | Baru simulasi backtest (kausal). Belum ada runner PAPER portofolio dengan state bersama. |
| `recovery` | integrasi, integrasi/isolasi, kegagalan/recovery | test_recovery, test_v020_failure_recovery, test_v030_isolation, test_v030_pipeline | 71 | 0 | Pemulihan hanya PAPER; belum ada rekonsiliasi posisi terhadap bursa sungguhan. |
| `risk` | audit implementasi, integrasi, integrasi/kegagalan data+secret, kegagalan/recovery, unit | test_core, test_v020_failure_recovery, test_v020_portfolio, test_v020_safeguard_wiring, test_v030_data_secrets, test_v030_m1_audit, test_v030_pipeline | 170 | 0 | - |
| `safeguard` | integrasi, integrasi/UI-API, integrasi/isolasi, kegagalan/recovery, unit | test_safeguard, test_v020_failure_recovery, test_v030_dashboard, test_v030_isolation, test_v030_pipeline | 101 | 0 | Pelepasan halt manual; belum ada pemantau eksternal (heartbeat) yang memicu HALT otomatis. |
| `statemachine` | integrasi, unit | test_roadmap_modules, test_v030_pipeline | 49 | 0 | Terhubung ke engine dan state paper (tes pipeline/persistensi). Belum diuji terhadap bursa karena tidak ada adapter bursa. |
| `strategies` | integrasi | test_v020_modes | 13 | 0 | - |
| `strategy` | audit implementasi, integrasi, unit | test_core, test_v020_modes, test_v030_m1_audit | 60 | 0 | Mode H1/M1 diuji pada data SINTETIS; kelayakan pada pasar nyata belum dibuktikan. |
| `telegram_notifier` | integrasi/kegagalan data+secret, unit | test_telegram_notifier, test_v030_data_secrets | 26 | 0 | Hanya server tiruan; Telegram sungguhan belum diuji. Hanya KIRIM notifikasi, tidak menerima perintah. |
| `timecontract` | unit | test_roadmap_modules | 18 | 0 | - |
| `validation` | integrasi, unit | test_core, test_fixes_v011 | 40 | 0 | Holdout belum dipakai pada data nyata. |
