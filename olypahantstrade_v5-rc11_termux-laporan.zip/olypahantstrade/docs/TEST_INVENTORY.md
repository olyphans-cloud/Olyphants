# Inventaris tes (kode v0.3.0)

**Total: 284 tes — 284 lulus, 0 gagal, 0 dilewati.** Lingkungan: Python 3.12, Linux, hanya pustaka standar (tanpa instalasi paket).

## Dijalankan

| Berkas tes | Jenis | Tes | Lulus | Gagal | Dilewati |
|---|---|---|---|---|---|
| `test_core` | unit | 31 | 31 | 0 | 0 |
| `test_fixes_v011` | integrasi | 9 | 9 | 0 | 0 |
| `test_mtf_strategy` | unit | 3 | 3 | 0 | 0 |
| `test_paper` | integrasi | 6 | 6 | 0 | 0 |
| `test_recovery` | kegagalan/recovery | 4 | 4 | 0 | 0 |
| `test_roadmap_modules` | unit | 18 | 18 | 0 | 0 |
| `test_safeguard` | unit | 6 | 6 | 0 | 0 |
| `test_telegram_notifier` | unit | 2 | 2 | 0 | 0 |
| `test_v020_failure_recovery` | kegagalan/recovery | 19 | 19 | 0 | 0 |
| `test_v020_modes` | integrasi | 13 | 13 | 0 | 0 |
| `test_v020_portfolio` | integrasi | 23 | 23 | 0 | 0 |
| `test_v020_safeguard_wiring` | integrasi | 26 | 26 | 0 | 0 |
| `test_v030_config_warnings` | unit | 5 | 5 | 0 | 0 |
| `test_v030_dashboard` | integrasi/UI-API | 28 | 28 | 0 | 0 |
| `test_v030_data_secrets` | integrasi/kegagalan data+secret | 24 | 24 | 0 | 0 |
| `test_v030_isolation` | integrasi/isolasi | 17 | 17 | 0 | 0 |
| `test_v030_m1_audit` | audit implementasi | 16 | 16 | 0 | 0 |
| `test_v030_pipeline` | integrasi | 31 | 31 | 0 | 0 |
| `test_wallet_and_architecture` | arsitektur | 3 | 3 | 0 | 0 |

## Belum dijalankan (tidak ada klaim hasil)

- Pengambilan data pasar NYATA (klines, bookTicker) — sandbox tanpa internet; skrip `scripts/verify_live_data.py` disediakan untuk perangkat Anda.
- Backtest, walk-forward, dan holdout pada data BTC nyata (hanya sintetis yang dijalankan).
- Paper trading berhari/berminggu pada data nyata.
- Telegram ke API sungguhan (hanya server tiruan).
- Tampilan dashboard di browser sungguhan (hanya HTTP API + script halaman di Node dengan DOM tiruan).
- Lintas platform: hanya Python 3.12 di Linux; belum Termux/Windows/macOS/Python 3.10–3.11.
- Dua proses OS terpisah menjalankan M1 dan H1 serentak (diuji: dua thread satu proses + lock berkas + state terpisah).
- Testnet/LIVE (terkunci; tidak ada adapter bursa).
- Kegagalan perangkat keras/jaringan sungguhan (disk penuh disimulasikan dengan injeksi os.replace).
