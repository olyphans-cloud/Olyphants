# Instal dan jalankan tes dari lingkungan bersih

Tidak ada dependensi pihak ketiga (hanya pustaka standar Python 3.10+; diuji pada 3.12 di Linux). Node.js opsional (satu tes script halaman dashboard; dilewati bila tidak ada).

```bash
unzip olypahantstrade_v5-rc1.zip && cd olypahantstrade
python3 -m venv .venv && . .venv/bin/activate        # opsional; tidak ada paket untuk diinstal
python3 -m unittest discover -s tests -t .           # seluruh tes
python3 scripts/gate_evidence.py                     # bukti per modul + matriks gerbang + inventaris tes
python3 scripts/repro_v4_bugs.py .                   # reproduksi 9 temuan audit (semua harus TIDAK)
python3 scripts/package_check.py ../olypahantstrade_v5-rc1.zip   # tanpa secret/state/cache
```

## Menjalankan
```bash
python3 -m btc_robot --config config.h1.example.json backtest --synthetic 3000
python3 -m btc_robot --config config.m1.example.json backtest --synthetic 20000
python3 -m btc_robot portfolio-backtest --spec portfolio.example.json
python3 -m btc_robot dashboard --demo --port 8765     # http://127.0.0.1:8765 (data sintetis, tanpa jaringan, tanpa uang asli)
python3 scripts/verify_live_data.py                   # data publik nyata (butuh internet; tanpa order)
python3 scripts/analyze_m1.py walkforward --mode m1 --csv BTCUSDT_1m.csv    # data nyata
```
Secret: salin `.env.example` ke `.env` dan isi token **baru**; `.env` tidak pernah dimasukkan ke ZIP.
