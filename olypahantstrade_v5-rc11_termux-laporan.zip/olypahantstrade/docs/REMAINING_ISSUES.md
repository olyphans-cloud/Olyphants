# Masalah yang masih tersisa dan alasan teknisnya

| # | Masalah | Alasan teknis | Dampak | Langkah berikutnya |
|---|---|---|---|---|
| 1 | Data pasar nyata belum diuji | Sandbox pembuatan tidak punya akses internet | G1, G2, G5 tidak bisa dinilai | Jalankan `scripts/verify_live_data.py`, `scripts/download_btc_history.py` di perangkat Anda |
| 2 | Kelayakan M1/H1 tidak terbukti | Semua backtest memakai data sintetis (random walk) | Status M1 dan H1 tetap BELUM LULUS | `scripts/analyze_m1.py ... --csv` pada data nyata; paper berminggu-minggu |
| 3 | M1 struktural rawan biaya | Biaya pulang-pergi ≈ jarak stop; filter `min_edge_cost_mult` tidak melindungi dari kondisi ini | Nilai harapan ≈ −biaya kecuali edge besar | Keputusan pemilik: batasi M1 dengan syarat biaya/stop, atau tunda M1. Tidak diubah tanpa data nyata |
| 4 | Tidak ada adapter order bursa | TESTNET/LIVE sengaja terkunci | G4, G6–G8 tak terjangkau; "status order tak diketahui" hanya disimulasikan | Diputuskan pemilik setelah G0–G5 |
| 5 | Risiko bersama hanya di simulasi backtest | `PortfolioRiskGate` dipakai `run_portfolio_backtest`; dashboard menjalankan tiap sleeve (mode × koin) dengan state terpisah tanpa gerbang bersama | M1 dan H1 pada koin sama di PAPER bisa memegang posisi serentak | Hubungkan gerbang bersama ke runner paper (butuh state bersama lintas proses) |
| 6 | Spread paper = proksi | Diukur saat pemrosesan (sekitar close candle), bukan saat fill di open | Tidak setara spread fill nyata | Runner live-loop pada open candle (bagian shadow/G4) |
| 7 | `max_hold`/trailing bergranularitas candle | Tanpa tick; batas "90 detik" tak bisa ditegakkan pada candle 1m | M1 tidak bisa menutup sub-menit | Butuh tick stream |
| 8 | Dashboard: aturan antarmuka "yang telah disepakati" tidak saya miliki | Dokumen permintaan hanya mencantumkan daftar fitur | Tata letak/tombol mungkin berbeda dari kesepakatan | Kirim aturan antarmuka tertulis; saya cocokkan |
| 9 | Dashboard belum diuji di browser sungguhan | Tidak ada browser di sandbox; teruji: HTTP API + script halaman di Node (DOM tiruan) | Tampilan visual/CSS tidak terverifikasi | Buka `python -m btc_robot dashboard --demo` dan tinjau |
| 10 | Telegram sungguhan belum diuji | Hanya server tiruan | Pengiriman nyata tak terverifikasi | Uji dengan bot Anda (token baru) |
| 11 | Tanpa pemantau eksternal (heartbeat) | Proses mati ⇒ tidak ada alert; state tetap konsisten | Kegagalan senyap | Watchdog/cron + notifikasi |
| 12 | Batas drawdown/rugi harian dievaluasi saat ada sinyal baru; rugi harian hanya yang terealisasi | Desain RiskEngine | Drawdown mengambang tak memicu halt sampai sinyal berikutnya | Evaluasi per candle (perlu keputusan) |
| 13 | Identitas state tidak mendeteksi perubahan parameter strategi/risiko pada state yang sama | Identitas = (mode, simbol, interval) | Parameter bisa berubah antar-run tanpa penolakan (hash config tercatat di audit) | Tambahkan hash parameter dengan prosedur migrasi |
| 14 | Audit log bersifat at-least-once saat langkah diulang setelah crash | Audit ditulis sebelum commit state | Event ganda; rantai hash tetap valid | Idempotensi event (opsional) |
| 15 | Holdout tanpa prefiks warm-up | `evaluate_holdout_once` memakai 20% akhir saja | Beberapa candle awal holdout tak menghasilkan sinyal | Tambahkan warm-up non-skor |
| 16 | Lintas platform belum diuji | Hanya Python 3.12/Linux; lock berkas memakai `fcntl` (tidak ada di Windows: dilewati) | Perilaku Termux/Windows belum terverifikasi | Jalankan suite di perangkat target |
| 17 | Token dashboard terbaca oleh proses lokal lain | Model ancaman: hanya loopback | Proses lokal berbahaya bisa memakai dashboard | Jangan jalankan di mesin bersama; tidak ada akses jaringan |
