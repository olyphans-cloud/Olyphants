# M1 dan H1 — laporan audit dan evaluasi

Dibuat otomatis oleh `scripts/build_m1_report.py` dari `docs/m1_audit/*`. **Semua angka berasal dari data SINTETIS (random walk)** kecuali Anda menjalankan skrip dengan `--csv`. Data sintetis tidak punya edge by construction (selain persistensi tren kecil per 200 candle), sehingga hasilnya **tidak membuktikan apa pun tentang pasar nyata**.

## 0. Status

| Mode | Status | Alasan ringkas |
|---|---|---|
| M1 | **BELUM LULUS** | Implementasi lolos audit, tetapi biaya pulang-pergi ≈ jarak stop; negatif setelah biaya di semua jendela walk-forward dan holdout (sintetis). Belum ada data nyata. |
| H1 | **BELUM LULUS** | Struktur biaya jauh lebih sehat, hasil campuran (3/4 jendela positif, holdout kecil negatif, hanya 9 transaksi). Belum ada data nyata. |

Tidak ada parameter strategi/risiko yang diubah: tidak ada varian yang positif setelah biaya pada bukti yang ada, jadi tidak ada dasar pengujian untuk perubahan. Satu-satunya perubahan terkait M1 adalah **peringatan konfigurasi** (tidak mengubah perilaku).

**Tentang angka di permintaan** (M1: 22 transaksi, −1,95%; H1: 10 transaksi, +1,60%): angka itu bukan dari run ini dan tidak dapat direproduksi tanpa data/seed/konfigurasinya. Hasil di bawah memakai data, seed, biaya, dan konfigurasi yang dicantumkan pada tiap tabel.

## 1. Audit implementasi M1 (tes otomatis, semuanya lulus)

`tests/test_v030_m1_audit.py` (16 tes), diverifikasi dengan *mutation check* (sinyal mengintip masa depan, fee separuh, slippage hanya satu sisi — semuanya terdeteksi):

| Pemeriksaan | Hasil |
|---|---|
| Tanpa look-ahead: sinyal di i identik dengan data terpotong sampai i; mengubah candle masa depan tidak mengubah sinyal lampau | lulus |
| Timestamp: entry = OPEN candle setelah candle sinyal; sinyal memakai CLOSE candle yang sudah tutup | lulus |
| Setiap approved order = entry atau di-veto tahap berikutnya (tidak ada order hilang) | lulus |
| Biaya dihitung ulang independen per transaksi (fee, gross, net) dan ekuitas rekonsiliasi dengan ledger | lulus (presisi 1e-8) |
| Dunia tanpa biaya: net == gross untuk semua transaksi | lulus |
| Lot: kelipatan lot_step, ≥ min_qty, ≥ min_notional, ≤ batas notional; qty dibulatkan ke bawah | lulus |
| Karakterisasi model fill: TP terisi saat *tersentuh* (optimis), stop menang bila keduanya tersentuh (pesimis), gap menembus stop terisi di open | terdokumentasi + lulus |

**Kesimpulan audit:** tidak ditemukan bug implementasi pada sinyal, waktu, atau biaya M1. Kerugian M1 bukan akibat kesalahan kode yang terdeteksi.

## 2. Rincian transaksi

CSV lengkap: `docs/m1_audit/m1_trades.csv` (79 transaksi) dan `h1_trades.csv`. Kolom: waktu, arah, alasan entry, harga referensi vs fill, alasan exit, durasi, PnL **sebelum biaya**, biaya spread+slippage, fee, PnL bersih, stop/TP rencana, biaya pulang-pergi %, rasio biaya/stop. Contoh 8 baris pertama M1:

| no | entry_time_utc | signal_reason | exit_reason | hold_minutes | gross_before_costs | net_pnl | cost_to_stop_ratio |
|---|---|---|---|---|---|---|---|
| 1 | 2023-11-14 23:19:00 | m1_pullback_up rsi=58.2 | stop | 11.0 | 1.3873 | 0.1967 | 0.91 |
| 2 | 2023-11-14 23:34:00 | m1_pullback_up rsi=58.9 | stop | 12.0 | -1.2715 | -2.4993 | 0.97 |
| 3 | 2023-11-15 02:15:00 | m1_pullback_up rsi=53.7 | max_hold | 29.0 | 3.1919 | 1.9040 | 1.06 |
| 4 | 2023-11-15 02:55:00 | m1_pullback_up rsi=56.3 | stop | 4.0 | -1.2914 | -2.4974 | 0.93 |
| 5 | 2023-11-15 03:47:00 | m1_pullback_up rsi=62.2 | stop | 14.0 | 2.1595 | 0.9139 | 1.00 |
| 6 | 2023-11-15 04:03:00 | m1_pullback_up rsi=64.1 | stop | 27.0 | -1.2841 | -2.4938 | 0.94 |
| 7 | 2023-11-15 05:22:00 | m1_pullback_up rsi=57.1 | stop | 1.0 | -1.1619 | -2.4876 | 1.14 |
| 8 | 2023-11-15 05:49:00 | m1_pullback_up rsi=61.7 | stop | 14.0 | -1.1743 | -2.4811 | 1.11 |

## 3. Sumber kerugian M1 (baseline resmi, data sintetis n=20.000 candle 1m, seed 1)

Run **berhenti oleh halt drawdown** pada candle ke-6,298 dari 20,000 (`max_drawdown 8.14%`, batas 8%). Itu kontrol risiko yang bekerja, tetapi berarti 69% data tidak terpakai.

| Komponen | USDT |
|---|---|
| Laba kotor sebelum biaya (harga referensi) | 17.30 |
| Biaya spread + slippage | -15.50 |
| Fee | -81.73 |
| **PnL bersih** | **-79.94** |

Total biaya = 97.23 vs laba kotor 17.30: biaya 5.6× laba kotor.

**Struktur (aritmetika dari config + data, bukan tebakan):**

| Besaran | M1 | H1 |
|---|---|---|
| Rata-rata jarak stop (%) | 0.170 | 1.912 |
| Rata-rata jarak TP (%) | 0.509 | 3.824 |
| Biaya pulang-pergi (%) | 0.180 | 0.280 |
| **Biaya / jarak stop** | **1.06** | **0.15** |
| P(TP sebelum SL) pada random walk | 25% | 33% |
| Win rate impas setelah biaya | 51.5% | 38.2% |
| Win rate aktual | 26.6% | 42.6% |
| EV per transaksi pada random walk (%) | -0.180 | -0.280 |

Untuk M1, biaya pulang-pergi sebanding dengan jarak stop (rasio ≈ 1). Dengan RR 3:1 pada pergerakan acak, peluang mencapai TP ≈ 25%, sedangkan win rate impas setelah biaya ≈ 51%. Akibatnya nilai harapan per transaksi ≈ −biaya, kecuali sinyal punya edge yang besar. Filter `min_edge_cost_mult` **tidak pernah aktif** pada konfigurasi ini (TP selalu > 2× biaya) sehingga tidak melindungi dari kondisi ini (lihat ablasi `no_edge_filter` = baseline).

| Alasan exit (M1) | n | rata-rata net | rata-rata durasi (menit) |
|---|---|---|---|
| max_hold | 3 | -0.394 | 29.0 |
| stop | 68 | -1.427 | 8.8 |
| take_profit | 8 | 2.284 | 11.6 |

## 4. Pembanding entry-acak (apakah sinyal M1 menambah sesuatu?)

60 run dengan entry LONG acak (peluang 4.77% per candle), stop/TP/filter/exit **identik**, data sama (10,000 candle), konfigurasi diagnostik tanpa halt drawdown agar horizon sama.

|  | M1 | Entry acak (rata-rata) |
|---|---|---|
| Transaksi | 237 | 275 |
| Win rate | 30.4% | 26.0% |
| Laba kotor / transaksi | 0.378 | 0.273 |
| Net / transaksi | -0.783 | -0.851 |
| Net total | -185.64 | -233.95 (p05 -263.50, p95 -214.25) |

Laba kotor/transaksi M1 berada di persentil ke-93 dibanding entry acak (tidak signifikan secara statistik, ambang umum 95). Net total M1 lebih baik dari acak terutama karena **lebih sedikit transaksi (biaya lebih sedikit)**, bukan karena kualitas entry yang jelas lebih baik. Keduanya tetap negatif.

## 5. Kondisi pasar (sintetis terkendali; jumlah dari 3 seed; konfigurasi diagnostik tanpa halt)

**M1** (n=10.000 candle 1m per seed)

| Regime | Transaksi | Win rate | Laba kotor | Biaya (spread+slip+fee) | Net |
|---|---|---|---|---|---|
| downtrend | 518 | 14.1% | -102.78 | 583.33 | -686.11 |
| high_vol | 831 | 43.1% | 185.00 | 512.45 | -327.45 |
| low_vol | 0 | 0.0% | 0.00 | 0.00 | 0.00 |
| sideways | 640 | 17.3% | -85.72 | 706.03 | -791.76 |
| uptrend | 795 | 26.2% | 174.27 | 884.21 | -709.94 |

**H1** (n=6.000 candle 1h per seed)

| Regime | Transaksi | Win rate | Laba kotor | Biaya (spread+slip+fee) | Net |
|---|---|---|---|---|---|
| downtrend | 135 | 28.1% | -92.13 | 80.77 | -172.90 |
| high_vol | 28 | 42.9% | 37.70 | 7.38 | 30.32 |
| low_vol | 156 | 34.6% | 21.28 | 191.77 | -170.49 |
| sideways | 209 | 31.6% | -52.94 | 125.39 | -178.34 |
| uptrend | 180 | 36.1% | 57.29 | 108.18 | -50.89 |

Catatan: `low_vol` M1 = 0 transaksi karena filter ATR minimum (`min_atr_pct`) menolak pasar sangat tenang; itu perilaku filter, bukan bukti profit. Regime tren hanya punya drift kecil buatan; ini bukan pasar nyata.

## 6. Ablasi (DIAGNOSTIK — tidak ada parameter yang dipilih dari sini)

Data sintetis campuran n=10.000 × 3 seed, konfigurasi diagnostik tanpa halt.

| Varian | Transaksi | Laba kotor | Biaya | Net |
|---|---|---|---|---|
| baseline | 693 | 230.39 | 798.76 | -568.37 |
| no_cooldown | 778 | 264.91 | 886.12 | -621.20 |
| no_edge_filter | 693 | 230.39 | 798.76 | -568.37 |
| no_max_hold | 694 | 229.80 | 799.42 | -569.62 |
| no_rsi_filter | 698 | 238.57 | 804.89 | -566.32 |
| no_trailing | 577 | 249.47 | 678.27 | -428.80 |
| wider_stop_3atr | 640 | 211.85 | 619.43 | -407.59 |
| zero_cost | 774 | 450.29 | 0.00 | 450.29 |

Semua varian dengan biaya nyata **negatif**; hanya `zero_cost` positif, artinya sinyal punya laba kotor positif tipis pada data yang memang punya persistensi tren kecil, tetapi biaya lebih dari dua kali lipat edge itu. Varian yang mengurangi jumlah transaksi (tanpa trailing, stop lebih lebar) mengurangi kerugian karena mengurangi biaya, tetapi tetap negatif; tidak ada dasar untuk mengadopsinya.

## 7. Sensitivitas asumsi eksekusi

| Asumsi | Net (3 seed) | Transaksi |
|---|---|---|
| TP butuh penetrasi 0.0 bps | -568.37 | 693 |
| TP butuh penetrasi 1.0 bps | -571.74 | 693 |
| TP butuh penetrasi 2.0 bps | -575.44 | 693 |
| TP butuh penetrasi 5.0 bps | -583.04 | 693 |
| Biaya × 0.5 | -240.34 | 741 |
| Biaya × 1.0 | -568.37 | 693 |
| Biaya × 2.0 | 0.00 | 0 |

Asumsi TP-saat-tersentuh (optimis) bukan penyebab kerugian. Biaya × 2 → 0 transaksi karena filter edge akhirnya aktif.

## 8. Walk-forward dan holdout (parameter tetap sejak awal; holdout tidak dipakai memilih apa pun; biaya termasuk)

**M1** — sumber: sintetis n=20000 seed=1; fee 0.00075, spread 1.0 bps, slippage 1.0 bps

| Jendela | Transaksi | Win rate | Fee | Net | Return | Max DD |
|---|---|---|---|---|---|---|
| 0 | 58 | 29.3% | 60.85 | -50.22 | -5.03% | 5.21% |
| 1 | 48 | 31.2% | 48.78 | -38.51 | -3.88% | 4.56% |
| 2 | 45 | 22.2% | 47.03 | -58.63 | -6.00% | 6.00% |
| 3 | 54 | 31.5% | 56.07 | -45.60 | -4.58% | 4.75% |
| **holdout** | 41 | 19.5% | 43.12 | -46.76 | -4.68% | 4.68% |

**H1** — sumber: sintetis n=6000 seed=1; fee 0.00100, spread 2.0 bps, slippage 3.0 bps

| Jendela | Transaksi | Win rate | Fee | Net | Return | Max DD |
|---|---|---|---|---|---|---|
| 0 | 10 | 60.0% | 4.73 | 22.39 | 2.25% | 1.61% |
| 1 | 7 | 71.4% | 3.44 | 30.81 | 3.58% | 0.97% |
| 2 | 8 | 50.0% | 3.68 | 12.92 | 1.29% | 1.90% |
| 3 | 12 | 16.7% | 5.44 | -33.13 | -3.33% | 3.70% |
| **holdout** | 9 | 33.3% | 4.28 | -5.88 | -0.59% | 1.46% |

## 9. Sebelum dan sesudah perbaikan kode (v4 vs sekarang; data, biaya, dan aturan risiko sama)

| Kasus | Versi | Transaksi | Return % | Max DD % | Fee | Halt | Hash |
|---|---|---|---|---|---|---|---|
| H1 1h | v4 | 47 | 2.7477 | 5.432 | 22.803 | - | 39c9445c5825 |
| H1 1h | sekarang | 47 | 2.7477 | 5.432 | 22.803 | - | 39c9445c5825 |
| M1 1m | v4 | 79 | -7.9935 | 8.1394 | 81.7303 | max_drawdown 8.14% | b1a831ed1dfa |
| M1 1m | sekarang | 79 | -7.9935 | 8.1394 | 81.7303 | max_drawdown 8.14% | b1a831ed1dfa |
| MTF 15m | v4 | 83 | 10.1998 | 3.3105 | 38.865 | - | 739d19906c93 |
| MTF 15m | sekarang | 83 | 10.2189 | 2.8257 | 38.7917 | - | 3d93f705f0b2 |

H1 dan M1 **identik** (hash sama): perombakan isolasi, pipeline, dan state machine tidak menggeser hasilnya. MTF berubah sedikit karena **cooldown breaker kini dimulai saat rugi ke-3 ditutup**, bukan pada sinyal berikutnya yang kebetulan dievaluasi.

## 10. Yang dibutuhkan untuk menilai M1/H1 dengan sah

1. Data candle nyata multi-tahun (`python3 scripts/download_btc_history.py`, lalu varian 1m/1h), divalidasi dengan `validate-data`.
2. `python3 scripts/analyze_m1.py walkforward --mode m1 --csv <file>` dan bagian lain dengan `--csv`; holdout dipakai **sekali**.
3. Paper trading berminggu-minggu pada data nyata (`scripts/run_paper_24h.sh` atau dashboard) dengan biaya sesuai akun Anda.
4. Audit independen ChatGPT atas ZIP, lalu persetujuan Anda. Sampai itu terpenuhi, status M1 dan H1 tetap **BELUM LULUS**.
