# Laporan swing 4h/1d: SPOT vs FUTURES (4h: d1h4_spot/d1h4_futures, 1d: lab_trend)
Sumber: SINTETIS (tidak bermakna untuk profit); funding 0.010%/8j dipotong pasca-hoc di futures.

| Simbol | TF | Pasar | Trx | Return% | MaxDD% | PF | WF+ | LONG trx/% | SHORT trx/% | Funding% |
|---|---|---|---|---|---|---|---|---|---|---|
| BTCUSDT | 4h | spot | 1 | 0.82 | 1.2 | - | 1/4 | 1 / +0.8 | 0 / +0.0 | 0.00 |
| BTCUSDT | 4h | futures | 47 | -1.81 | 9.6 | 0.94 | 2/4 | 26 / +1.0 | 21 / -2.6 | 0.21 |
| BTCUSDT | 1d | spot | 22 | 5.51 | 5.1 | 1.48 | 2/4 | 22 / +5.5 | 0 / +0.0 | 0.00 |
| BTCUSDT | 1d | futures | 46 | 5.58 | 6.7 | 1.38 | 3/4 | 22 / +5.8 | 24 / +2.1 | 2.33 |
| ETHUSDT | 4h | spot | 0 | 0.00 | 0.0 | - | 0/4 | 0 / +0.0 | 0 / +0.0 | 0.00 |
| ETHUSDT | 4h | futures | 59 | -6.06 | 10.8 | 0.84 | 1/4 | 45 / +0.5 | 14 / -6.2 | 0.33 |
| ETHUSDT | 1d | spot | 30 | 25.35 | 5.6 | 3.17 | 3/4 | 30 / +25.3 | 0 / +0.0 | 0.00 |
| ETHUSDT | 1d | futures | 49 | 21.87 | 6.0 | 2.21 | 3/4 | 30 / +26.1 | 19 / -1.5 | 2.73 |
| BNBUSDT | 4h | spot | 0 | 0.00 | 0.0 | - | 0/4 | 0 / +0.0 | 0 / +0.0 | 0.00 |
| BNBUSDT | 4h | futures | 63 | 6.25 | 5.0 | 1.18 | 3/4 | 34 / -0.1 | 29 / +6.9 | 0.49 |
| BNBUSDT | 1d | spot | 11 | 12.35 | 2.5 | 5.84 | 1/4 | 11 / +12.3 | 0 / +0.0 | 0.00 |
| BNBUSDT | 1d | futures | 48 | 20.57 | 5.3 | 2.55 | 3/4 | 11 / +13.9 | 37 / +9.1 | 2.47 |
| SOLUSDT | 4h | spot | 1 | -0.65 | 1.4 | 0.00 | 0/4 | 1 / -0.7 | 0 / +0.0 | 0.00 |
| SOLUSDT | 4h | futures | 64 | 7.29 | 7.9 | 1.21 | 3/4 | 30 / +3.4 | 34 / +4.2 | 0.34 |
| SOLUSDT | 1d | spot | 13 | -0.55 | 5.0 | 0.91 | 2/4 | 13 / -0.5 | 0 / +0.0 | 0.00 |
| SOLUSDT | 1d | futures | 49 | 4.40 | 5.6 | 1.37 | 2/4 | 13 / -0.4 | 36 / +7.1 | 2.34 |
