# Berkas yang berubah (v4 → v0.3.0)

Dibuat otomatis oleh `scripts/files_changed.py` dari perbandingan isi berkas.

## Diubah (24)

| Berkas | Alasan |
|---|---|
| `CHANGELOG.md` | Entri v0.3.0 (temuan, perbaikan, status). |
| `README.md` | Isolasi state, jalur order, dashboard, laporan; judul/nama proyek. |
| `SAFEGUARD_AUDIT.md` | Ditulis ulang: pipeline order, integrasi StateMachine, batas yang jujur. |
| `btc_robot/__main__.py` | Perintah portfolio-backtest, scan, adopt-state, dashboard; peringatan konfigurasi ke stderr. |
| `btc_robot/audit.py` | Redaksi token Telegram yang muncul di dalam TEKS pesan error. |
| `btc_robot/config.py` | Field risiko baru (cooldown, max-hold, trailing, spread, edge, entri/jam), mode h1_trend/m1_scalp, kill switch bersama, sleeve_id, config_warnings, versi 0.3.0. |
| `btc_robot/data.py` | fetch_book_ticker; fetch_klines menolak respons non-list & TypeError; vol di generator sintetis. |
| `btc_robot/engine.py` | Pipeline order eksplisit HALT→Risk→SafeGuard→Portofolio→HALT final→eksekusi; integrasi StateMachine; begin_bar/end_bar; max-hold, trailing, spread, batas entry/jam; exec_unknown→RECONCILING. |
| `btc_robot/paper.py` | Cek identitas state sebelum menulis; persist/restore machine_state + validasi konsistensi; lock berkas; deteksi celah data; state rusak ditolak; last_equity untuk dashboard; fetch gagal apa pun→no_data. |
| `btc_robot/recovery.py` | Melihat latch HALT safeguard (bug buntu); cek identitas; RECONCILING→READY setelah persetujuan operator. |
| `btc_robot/risk.py` | Filter edge-vs-biaya; kill switch bersama. |
| `btc_robot/safeguard.py` | Cooldown berjangkar pada waktu rugi ke-3; pencatatan trade idempoten (replay setelah crash); release_halt tanpa reset loss streak. |
| `btc_robot/statemachine.py` | restore(), log transisi rutin senyap, riwayat terbatas (agar bisa dipakai engine). |
| `btc_robot/telegram_notifier.py` | api_base (uji), placeholder PUT_* dianggap belum dikonfigurasi, semua error ditangani tanpa membocorkan token, nama robot. |
| `btc_robot/validation.py` | Warm-up walk-forward otomatis; jendela memuat total_fees/net_pnl/win_rate. |
| `config.h1.example.json` | BARU/diubah: state_dir terpisah state/h1, kill switch bersama. |
| `config.m1.example.json` | BARU/diubah: state_dir terpisah state/m1, kill switch bersama. |
| `config.mtf.example.json` | state_dir terpisah state/mtf, kill switch bersama. |
| `docs/GATE_EVIDENCE.md` | Dokumen/laporan hasil (dibuat otomatis atau ditulis) |
| `docs/gate_evidence.json` | Dokumen/laporan hasil (dibuat otomatis atau ditulis) |
| `scripts/gate_evidence.py` | BARU: bukti per modul, matriks gerbang, inventaris tes. |
| `tests/test_recovery.py` | Fixture memakai identitas state (perilaku baru: state lama tanpa identitas ditolak). |
| `tests/test_v020_modes.py` | Golden hash MTF diperbarui dengan penjelasan (cooldown berjangkar). |
| `tests/test_v020_safeguard_wiring.py` | Menutup soket server tiruan. |

## Baru (23)

| Berkas | Alasan |
|---|---|
| `btc_robot/dashboard.py` | BARU: dashboard lokal PAPER (loopback, token, ACC tanpa order, statistik M1/H1 terpisah, AI Scan/Manual). |
| `btc_robot/identity.py` | BARU: identitas state per (mode, simbol, interval); penolakan aman bila campur/rusak/lama. |
| `docs/AUDIT_V5.md` | Dokumen/laporan hasil (dibuat otomatis atau ditulis) |
| `docs/FILES_CHANGED.md` | Dokumen/laporan hasil (dibuat otomatis atau ditulis) |
| `docs/GATE_MATRIX.md` | Dokumen/laporan hasil (dibuat otomatis atau ditulis) |
| `docs/INSTALL_AND_TEST.md` | Dokumen/laporan hasil (dibuat otomatis atau ditulis) |
| `docs/M1_H1_REPORT.md` | Dokumen/laporan hasil (dibuat otomatis atau ditulis) |
| `docs/REMAINING_ISSUES.md` | Dokumen/laporan hasil (dibuat otomatis atau ditulis) |
| `docs/TEST_INVENTORY.md` | Dokumen/laporan hasil (dibuat otomatis atau ditulis) |
| `scripts/analyze_m1.py` | BARU: rincian transaksi, atribusi, pembanding acak, regime, ablasi, sensitivitas, walk-forward. |
| `scripts/build_m1_report.py` | BARU: laporan M1/H1 dari hasil (tanpa angka manual). |
| `scripts/compare_versions.py` | BARU: perbandingan sebelum/sesudah pada data/biaya yang sama. |
| `scripts/files_changed.py` | BARU: pembuat berkas ini. |
| `scripts/package_check.py` | BARU: pemeriksa isi ZIP (secret/state/cache). |
| `scripts/repro_v4_bugs.py` | BARU: reproduksi 9 temuan audit terhadap pohon kode mana pun (v4 vs baru). |
| `scripts/verify_live_data.py` | BARU: uji data pasar publik di perangkat Anda (tanpa order). |
| `tests/js/dashboard_dom_check.js` | - |
| `tests/test_v030_config_warnings.py` | Tes baru untuk perbaikan v0.3.0 |
| `tests/test_v030_dashboard.py` | Tes baru untuk perbaikan v0.3.0 |
| `tests/test_v030_data_secrets.py` | Tes baru untuk perbaikan v0.3.0 |
| `tests/test_v030_isolation.py` | Tes baru untuk perbaikan v0.3.0 |
| `tests/test_v030_m1_audit.py` | Tes baru untuk perbaikan v0.3.0 |
| `tests/test_v030_pipeline.py` | Tes baru untuk perbaikan v0.3.0 |

## Dihapus (0)

| Berkas | Alasan |
|---|---|
