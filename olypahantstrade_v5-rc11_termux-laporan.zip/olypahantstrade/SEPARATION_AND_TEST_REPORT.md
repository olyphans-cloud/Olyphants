> **Dokumen historis (v2).** Status terkini: `docs/GATE_EVIDENCE.md` dan `CHANGELOG.md`.

# Separation and Test Report — BTC Robot

Date: 2026-10-13

## Changes made
- Removed `btc_robot/wallet_tracker.py` from the BTC package.
- Removed wallet-scanner unit tests from the BTC test suite; wallet tests now live only in the separate Altcoin Wallet Tracker package.
- Updated BTC README and audit notes to document that the wallet scanner is not included or imported.
- Packaged the scanner as a standalone `altcoin_wallet_tracker` package with no exchange order integration.

## Tests run
- BTC robot unit suite: **58 passed**.
- BTC synthetic backtest: **3,000 synthetic bars; 20 trades; 65% win rate; +7.2903% simulated return; 1.6087% maximum drawdown; profit factor 3.0339; simulated fees 9.6424**.
- Altcoin Wallet Tracker unit suite: **6 passed**.

## Important limits
- The positive backtest result above is on synthetic data only and is not evidence of real-market profitability.
- No real BTC historical-data test was run in this step because no market dataset was included in the source ZIP.
- No exchange testnet order was submitted. This package has no testnet execution adapter; TESTNET/LIVE remain locked by design.
- The scanner is separated as a package, but its real BNB Chain RPC/BscScan data adapter is not implemented.
- These tests validate current unit behavior only; they do not mean the roadmap release gates have passed.
