# olypahantstrade — robot trading BTC, kerangka (bukan siap live)

Implementasi inti **olypahantstrade**, robot trading BTC (Governance & Architecture). Nama paket Python tetap `btc_robot` (perintah: `python -m btc_robot`). Wallet scanner BNB Chain dipisahkan ke paket tersendiri. Hanya Python standar (3.10+), jalan di Termux.
Acuan: Master Roadmap v1.0 (gerbang G0–G8). **Belum ada gerbang yang lulus.** Tidak ada klaim profit.
Pemetaan lengkap roadmap → kode ada di `ROADMAP_GAP_ANALYSIS.md`.

## Struktur
| File | Peran (Dok 01) |
|------|----------------|
| `config.py` | Config tervalidasi; LIVE/TESTNET terkunci |
| `gates.py` | Registri G0–G8 + kunci LIVE 3 lapis (butuh G0–G6) |
| `timecontract.py` | Status data (KNOWN/STALE/…), clock health, snapshot keputusan, Decision ID |
| `statemachine.py` | State machine, presedensi kegagalan, mode degradasi (belum dipasang ke engine) |
| `data.py` | Ingestion, validasi (celah/duplikat/OHLC/basi), fingerprint, data sintetis |
| `indicators.py`, `strategy.py` | Indikator kausal + strategi contoh (tanpa jalur ke order) |
| `risk.py` | Satu-satunya penyetuju order; order ditandatangani HMAC; halt latch |
| `execution.py` | Adapter SIMULASI (fee, spread, slippage, lot, idempoten) |
| `ledger.py` | Kas, posisi, PnL, rekonsiliasi |
| `audit.py` | Log JSONL berantai-hash + redaksi rahasia |
| `engine.py` | Pemroses candle (dipakai backtest & paper) |
| `backtest.py`, `validation.py` | Backtest reproducible, walk-forward, holdout sekali-pakai |
| `paper.py` | `paper-step` per pemanggilan (cron/Termux) |

## Pakai
```bash
python -m unittest discover -s tests -t .          # semua tes
python -m btc_robot backtest --csv data.csv         # CSV: ts,open,high,low,close,volume (ms UTC)
python -m btc_robot backtest --synthetic 3000       # data SINTETIS, hanya uji mesin
python -m btc_robot walk-forward --csv data.csv
python -m btc_robot holdout --csv data.csv          # SEKALI saja
python -m btc_robot validate-data --csv data.csv
python -m btc_robot paper-step                      # perlu internet (klines publik Binance)
python -m btc_robot gates
```
Config opsional: `--config cfg.json` (kunci salah ketik ditolak). Emergency stop: buat file `state/KILL_SWITCH`.

## Keputusan yang butuh persetujuan pemilik
Lihat `AUDIT_DOC01.md` bagian A dan C (angka risiko, spot/futures, prosedur posisi terbuka saat darurat, kriteria G4/G5).


**Pemisahan modul:** paket BTC ini tidak menyertakan wallet scanner dan tidak mengimpor modul wallet tracker. Lihat paket `Altcoin_Wallet_Tracker_Separate.zip` untuk modul riset BNB Chain yang berdiri sendiri.

## Halt: diagnosis dan pemulihan terpandu (PAPER saja)

Periksa status sebelum mengambil tindakan:
```bash
python -m btc_robot halt-status
```

Jika status menyatakan pemulihan mungkin dilakukan, operator harus memastikan penyebab halt telah diselesaikan, posisi/order sudah diperiksa, dan file `state/KILL_SWITCH` sudah tidak aktif karena alasan yang sah. Kemudian:
```bash
python -m btc_robot recover-halt --approved-by "operator" --reason "akar masalah diperbaiki dan posisi/order diperiksa" --confirm-resolved
python -m btc_robot halt-status
python -m btc_robot paper-step
```

Perintah pemulihan menolak jika kill switch masih ada, state tidak sedang halt, atau audit hash-chain tidak valid. Pemulihan hanya membuka latch pada state PAPER; tidak mereset saldo, ledger, posisi, batas risiko, atau riwayat. Identitas operator dan alasan dicatat pada state dan audit log. Jangan gunakan perintah ini untuk melewati batas risiko yang masih aktif. Ini belum mengaktifkan TESTNET atau LIVE.

## Notifikasi Telegram (PAPER saja)

1. Salin `.env.example` menjadi `.env` di folder `olypahantstrade/` (folder paket ini).
2. Isi `TELEGRAM_BOT_TOKEN` dan `TELEGRAM_CHAT_ID` dengan token baru/rahasia dan chat ID milik Anda. Jangan kirim token ke chat atau unggah `.env`.
3. Jalankan `python -m btc_robot paper-step` dari folder proyek. Notifikasi akan dikirim untuk sinyal, posisi simulasi dibuka/ditutup, dan halt risiko yang terjadi saat proses berjalan.
4. Uji pengiriman secara terpisah dengan bot Telegram sebelum mengandalkan notifikasi. Kegagalan Telegram tidak mengubah keputusan trading.

Integrasi ini hanya mengirim pemberitahuan. Adapter tetap simulasi; TESTNET dan LIVE belum diimplementasikan/dibuka.

## Strategi multi-timeframe baru (1H → 30M → 15M)

File tambahan `btc_robot/mtf_strategy.py` (modul di dalam paket `btc_robot`) menerapkan alur berikut:
- **1H** menentukan arah tren dengan EMA cepat/lambat.
- **30M** harus mengonfirmasi arah yang sama.
- **15M** memicu kandidat entry ketika harga berada di sisi EMA yang sesuai dan RSI berada dalam rentang konfigurasi.
- Stop-loss berbasis ATR 15M dan target berdasarkan rasio reward/risk yang ada di konfigurasi.
- Candle 30M/1H hanya digunakan setelah lengkap; kelompok candle yang hilang/tidak lengkap tidak diagregasi.
- Risk engine tetap berwenang menolak sinyal; strategi tidak dapat mengirim order langsung.

Contoh konfigurasi ada di `config.mtf.example.json`. Untuk mengaktifkannya, gunakan `interval: "15m"` dan `strategy_mode: "mtf_1h_30m_15m"`. Mode lama tetap menjadi default (`ema_rsi`) agar perilaku proyek lama tidak berubah diam-diam. Contoh backtest data CSV:

```bash
python -m btc_robot --config config.mtf.example.json backtest --csv BTCUSDT_15m.csv
```

Batas satu entry per jam UTC ditambahkan pada mesin eksekusi dan disimpan dalam state PAPER. Penambahan ini lolos suite unit test lokal, tetapi **belum** merupakan bukti profitabilitas dan belum menggantikan backtest data historis BTC yang sebenarnya.

## Safeguard (v0.2.0: terhubung ke engine)
Circuit breaker (loss streak + cooldown), gerbang spread order book (PAPER), batas waktu posisi, trailing stop,
filter edge-vs-biaya, dan batas entry per jam kini dipanggil dari engine dan diatur lewat `risk.*` di config.
Rincian, batas, dan yang BELUM ada: `SAFEGUARD_AUDIT.md`. Ini bukan perlindungan bursa live.

## Mode H1, M1, dan MTF (mandiri)
| Mode | `strategy_mode` | interval | Config contoh |
|---|---|---|---|
| H1 | `h1_trend` | `1h` | `config.h1.example.json` |
| M1 | `m1_scalp` | `1m` | `config.m1.example.json` |
| MTF | `mtf_1h_30m_15m` | `15m` | `config.mtf.example.json` |
Interval yang tidak cocok ditolak oleh validasi. Parameter contoh adalah titik awal TANPA bukti; kelayakan M1/H1 pada
data nyata belum terbukti (tes memakai data sintetis).

## Portofolio multi-koin / multi-mode (simulasi backtest)
```bash
python -m btc_robot portfolio-backtest --spec portfolio.example.json   # beberapa sleeve (simbol x mode), risiko bersama
python -m btc_robot scan --spec portfolio.example.json                 # scanner manual/auto
```
`PortfolioRiskGate` membatasi posisi total, posisi per simbol, eksposur total, rugi harian total (blok sampai hari UTC
berikutnya), dan drawdown total (latch HALT). Gerbang hanya bisa MENOLAK entry. Belum ada runner PAPER portofolio.

## Isolasi M1/H1 dan state
Satu `state_dir` = satu (mode, simbol, interval): `identity.json` mencegah pencampuran (penolakan aman, tanpa menulis). Config contoh
memakai `state/h1`, `state/m1`, `state/mtf`; `shared_kill_switch_file` (`state/KILL_ALL`) menghentikan semua mode. State lama tanpa identitas:
`python -m btc_robot --config <cfg> adopt-state --confirm-identity`.

## Jalur order dan HALT
`HALT → Risk → SafeGuard → Portofolio → HALT final → eksekusi`, digerakkan oleh `StateMachine` (lihat `SAFEGUARD_AUDIT.md`).

## Dashboard (PAPER saja, tanpa uang asli)
```bash
python -m btc_robot dashboard --demo        # data sintetis;   tanpa --demo = data publik Binance
```
Hanya loopback. Pilih AI Scan/Manual, timeframe M1/H1 terpisah, koin, lalu **ACC** (hanya pemeriksaan keselamatan + aktivasi; ACC tidak pernah membuka
order). Order hanya lahir dari "Jalankan 1 siklus simulasi" melalui pipeline penuh. Tampilan visual belum diuji di browser sungguhan.

## Bukti, laporan, dan status gerbang
`python scripts/gate_evidence.py` membuat `docs/GATE_EVIDENCE.md`, `docs/GATE_MATRIX.md`, `docs/TEST_INVENTORY.md`. Laporan: `docs/AUDIT_V5.md`,
`docs/M1_H1_REPORT.md`, `docs/REMAINING_ISSUES.md`, `docs/INSTALL_AND_TEST.md`. **Tidak ada gerbang berstatus LULUS.**

## Skrip bantu
```bash
python3 scripts/download_btc_history.py                      # unduh BTCUSDT 15m 3 tahun -> BTCUSDT_15m.csv
python3 -m btc_robot --config config.mtf.example.json validate-data --csv BTCUSDT_15m.csv
python3 -m btc_robot --config config.mtf.example.json backtest --csv BTCUSDT_15m.csv
python3 -m btc_robot --config config.mtf.example.json walk-forward --csv BTCUSDT_15m.csv
bash scripts/run_paper_24h.sh                                # paper trading 24 jam (butuh internet)
```
Catatan: `validate-data` WAJIB memakai `--config` agar interval 15m terbaca (default 1h). Lihat `CHANGELOG.md`.
