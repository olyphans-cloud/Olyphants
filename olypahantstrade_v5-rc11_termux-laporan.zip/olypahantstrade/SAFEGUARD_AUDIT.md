# Status integrasi Safeguard / HALT / StateMachine (v0.3.0)

Bukti per modul: `docs/GATE_EVIDENCE.md`. Matriks gerbang: `docs/GATE_MATRIX.md`. Temuan dan perbaikan: `docs/AUDIT_V5.md`.

## Jalur order (satu-satunya jalan ke eksekusi) — `Engine._try_enter`, urutan diuji (`engine.PIPELINE`)
1. **HALT** (risk halt, safeguard halt, state machine/failure aktif) — paling awal, fail-closed.
2. **Risk Engine** — satu-satunya penerbit `ApprovedOrder` bertanda tangan; adapter menolak order tak bertanda tangan.
3. **Safe Guard** — circuit breaker (loss streak + cooldown), gerbang spread order book (PAPER), batas entry per jam.
4. **Gerbang portofolio** (opsional) — hanya bisa menolak.
5. **HALT final** — tepat sebelum submit (menangkap halt/kill switch yang muncul di tengah jalan).
6. **Eksekusi** — exception apa pun saat submit ⇒ HALT (`exec_unknown`, tanpa retry) dan state machine ⇒ RECONCILING.

## StateMachine terhubung ke engine dan state PAPER
Jalur: `READY → ANALYZING → SIGNAL → RISK_CHECK → EXECUTING → POSITION → EXITING → RECONCILING → READY`. Setiap veto kembali ke `READY`.
`machine_state` dipersist di `paper_state.json` dan **diverifikasi konsisten dengan ledger/pending** saat dimuat (tidak cocok ⇒ `state_inconsistent`,
state tidak diubah). Transisi ilegal ⇒ HALT. Setelah order status tak diketahui, mesin berhenti di `RECONCILING` sampai operator menyetujui `recover-halt`.

## Terhubung dan teruji
| Fungsi | Catatan jujur |
|---|---|
| Circuit breaker + cooldown | Cooldown dimulai saat rugi ke-N ditutup (bukan malas); pencatatan trade idempoten untuk replay setelah crash |
| Spread order book | PAPER: `bookTicker` publik, diukur saat pemrosesan (proksi spread fill); sumber tak ada/basi/silang ⇒ ditolak. BACKTEST tidak punya order book (spread lewat `costs.spread_bps`) |
| Batas waktu posisi / trailing stop | Granularitas candle; trailing dihitung dari close dan berlaku candle berikutnya; stop tidak pernah turun |
| Filter edge vs biaya | Hanya memeriksa TP vs biaya; **tidak** memeriksa biaya vs jarak stop (lihat `docs/M1_H1_REPORT.md`) |
| Isolasi state | `identity.json` per state_dir; kill switch per-mode dan bersama |
| HALT latch | Terlihat oleh `diagnose`/`recover`; pelepasan wajib manual; loss streak/cooldown tidak di-reset |

## Belum ada
Adapter order bursa; pemantau eksternal (heartbeat); gerbang risiko bersama di runner PAPER (baru di simulasi backtest); tick stream. TESTNET/LIVE terkunci.
