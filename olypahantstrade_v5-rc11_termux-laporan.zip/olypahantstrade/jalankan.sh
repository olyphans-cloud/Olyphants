#!/data/data/com.termux/files/usr/bin/sh
# Satu perintah di Termux: unduh data BTC/BNB/SOL (4h+1d), backtest, tulis laporan .txt
cd "$(dirname "$0")" || exit 1
python scripts/laporan_txt.py "$@"
