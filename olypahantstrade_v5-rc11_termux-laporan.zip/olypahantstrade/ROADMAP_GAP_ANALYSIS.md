> **Catatan v0.2.0:** pemetaan ini ditulis sebelum penyambungan Safeguard, mode H1/M1, portofolio, dan tes kegagalan. Bukti terkini per modul: `docs/GATE_EVIDENCE.md`. Gerbang G0-G8 tetap belum lulus.

# Pemetaan Master Roadmap v1.0 → Kode

Legenda: ✅ ada + ada tes · 🟡 sebagian · ❌ belum ada · ⚠ butuh keputusan pemilik

**Status gerbang riil: G0–G8 semuanya BELUM lulus** (belum ada berkas bukti). Registri: `python -m btc_robot gates`.
Penomoran lama di Dok 01 (G0–G6) digantikan roadmap: gate lama "paper" kini G5, "testnet" kini G6, dan ada G4 Shadow baru.

## Per bagian roadmap
| Bagian | Status | Keterangan |
|---|---|---|
| 0 Prinsip: exchange = sumber kebenaran | 🟡 | `Ledger.reconcile()` ada, tapi belum ada exchange yang dibandingkan |
| 0 WAIT / INSUFFICIENT_EVIDENCE | 🟡 | `NO_TRADE` ada (alasan "warmup"); label INSUFFICIENT_EVIDENCE belum eksplisit |
| 2 Data & Time (status, clock, snapshot, ID) | ✅ modul / ❌ belum terpasang | `timecontract.py` diuji; belum dipakai oleh jalur data candle/paper. Decision ID sudah masuk audit log engine |
| 2 Order book snapshot+incremental, resync WS | ❌ | |
| 3 News & Macro | ❌ | Seluruhnya |
| 4 Market intelligence | 🟡 | Hanya EMA/RSI/ATR. Belum: regime + hysteresis, funding/OI/liquidation, order book, drift |
| 5 Decision & AI | 🟡 | Skema `Signal` deterministik, confidence `None`, sinyal kedaluwarsa ditolak. Belum: AI, abstain terstruktur, trade intent vs order plan terpisah |
| 6 Risk | 🟡 | ✅ veto, sizing, rugi harian, drawdown halt, HMAC. ❌ expected edge, funding, margin/likuidasi, korelasi, TTL approval |
| 7 Exchange & Execution | 🟡 | ✅ idempotensi + client_order_id (simulasi). ❌ constraint/health engine, partial fill, cancel/replace, timeout→reconcile, adapter nyata |
| 8 Position, Exit, Recovery | 🟡 | SL/TP simulasi pesimistis. ❌ thesis invalidation, jenis exit, recovery yang query exchange |
| 9 State machine + presedensi | ✅ modul / ❌ belum terpasang | `statemachine.py` diuji; engine candle belum memakainya |
| 10 Mode degradasi | ✅ tabel / ❌ penegakan | Tabel respons diuji; paper baru menangani data tidak valid |
| 11 Testing | 🟡 | ✅ unit, no-lookahead strategi, reproducibility, walk-forward, holdout sekali. ❌ stress, sensitivitas parameter, benchmark naif, failure-injection E2E, interval ketidakpastian |
| 12 Assurance | 🟡 | ✅ log hash-chain (tamper-evident, bukan penyimpanan immutable). ❌ decision replay, atribusi slippage/latency, post-trade/no-trade analysis, monitoring/alert/incident |
| 13 Security | 🟡 | ✅ redaksi, tes anti-secret di kode. ❌ pemisahan key dev/testnet/live, rotasi, backup |
| 14 Gerbang | ✅ registri G0–G8 | LIVE butuh G0–G6 + env + persetujuan terikat hash config |
| 15 Change management | ❌ | Baru `config_hash` di log; workflow proposal→approval belum ada |
| 16 Audit Claude × ChatGPT | proses | Ikuti urutan: audit independen dulu, baru cross-review |

## Catatan jujur tentang proses
Butir 19 roadmap: *"Jangan langsung coding seluruh robot; per modul, tes + bukti dulu."* Paket yang saya kirim
sebelumnya dibangun melebar sekaligus. Kodenya berjalan dan teruji, tetapi **tiap modul belum punya spesifikasi
INPUT → PROCESS → OUTPUT → FAILURE MODE → TEST → PASS CRITERIA yang Anda setujui (G0)**. Itu langkah berikutnya,
satu modul per putaran, mengikuti urutan implementasi di bagian 18.

## Keputusan yang dibutuhkan (⚠)
1. **Futures perpetual atau spot?** Roadmap membahas funding, leverage, margin, jarak likuidasi, OI. Kode saat ini spot tanpa leverage dan SHORT dimatikan. Jawabannya mengubah model biaya, risk engine, dan adapter.
2. **Exchange mana** (untuk data adapter, constraint engine, testnet).
3. **Strategi setup utama.** Roadmap menyebut market setup sebagai sumber keputusan; strategi EMA/RSI di kode hanya placeholder.
4. **Kebijakan AI**: provider, skema output, fallback deterministik.
5. **Angka risiko** (lihat `AUDIT_DOC01.md` bagian A).

## Urutan implementasi (bagian 18) — posisi sekarang
1 spec/config/security 🟡 · 2 time/clock/event ✅ · 3 data adapters ❌ (hanya klines publik, belum teruji jaringan) ·
4 validasi+snapshot+storage 🟡 · 5 exchange state/health/constraints ❌ · 6 market intelligence 🟡 · 7 news ❌ ·
8 strategy+schema+AI 🟡 · 9 risk 🟡 · 10 execution 🟡 · 11 position/recovery 🟡 · 12 observability 🟡 ·
13 backtest/replay 🟡 · 14 WFO/stress 🟡 · 15 shadow→paper→testnet ❌ · 16–18 ❌
