# Audit Dokumen 01 — Governance & Architecture

Tanggal audit: 2026-10-13. Dokumen 02–08 tidak tersedia, jadi semua keputusan di bawah adalah
**asumsi eksplisit** yang harus disetujui pemilik proyek.

> **Pembaruan:** Master Roadmap v1.0 kini menjadi acuan dan menggantikan penomoran gerbang di bawah
> (G0–G8; "paper" = G5, "testnet" = G6). Lihat `ROADMAP_GAP_ANALYSIS.md`.

## A. Kekurangan dokumen (dan cara kode menutupnya)

| # | Kekurangan di Dok 01 | Risiko | Keputusan di kode (perlu persetujuan pemilik) |
|---|----------------------|--------|-----------------------------------------------|
| 1 | Tidak ada angka batas risiko (risk per trade, rugi harian, drawdown). | Risk engine tidak bisa diuji. | `RiskConfig`: 0.5% per trade, rugi harian 2%, drawdown 10% (latch halt). |
| 2 | Spot vs futures tidak ditentukan, tetapi arsitektur menyebut LONG/SHORT. | SHORT spot tidak mungkin; funding/margin tak terhitung. | Default spot long-only (`allow_short=False`); SHORT hanya simulasi bila dinyalakan. Funding belum dimodelkan. |
| 3 | Exchange tidak ditentukan. | Aturan lot/fee berbeda. | Default parameter mirip Binance spot BTCUSDT; semua di `CostConfig`. |
| 4 | Gerbang G2–G5 tanpa kriteria angka ("cukup lama", "tanpa memakai holdout"). | Gerbang bisa dilewati subjektif. | `gates.py` mencatat status gerbang + bukti; `validation.py` memaksa holdout hanya boleh dievaluasi sekali. Angka minimum paper/testnet **belum ditetapkan** — harus diputuskan pemilik. |
| 5 | "Mode LIVE tidak aktif karena config tidak sengaja" tanpa mekanisme. | Live bisa aktif tak sengaja. | Tiga lapis: mode LIVE + env `BTC_ROBOT_LIVE_CONFIRM` + file gates (G0–G5 lulus + persetujuan terikat hash config). Adapter LIVE sengaja **tidak diimplementasikan**. |
| 6 | Prosedur posisi terbuka saat emergency stop tidak ditetapkan. | Posisi tanpa pengawasan. | Default: stop entri baru, posisi lama tetap dikelola stop/TP-nya. Pilihan "tutup paksa" belum ada; perlu keputusan. |
| 7 | Kebijakan fallback AI hanya "default NO-TRADE". | Ambigu untuk komponen non-AI. | Strategi saat ini deterministik; AI belum dipasang. Jalur AI harus memakai `Signal` yang sama dan lewat risk engine. |
| 8 | Rekonsiliasi: tidak ada toleransi/frekuensi. | Ledger drift tak terdeteksi. | `Ledger.reconcile(exchange_qty, tol)` + halt bila selisih; frekuensi dipanggil adapter testnet/live (belum ada). |
| 9 | Stop-loss di exchange atau lokal tidak ditentukan. | Gap/koneksi putus. | Simulasi: stop lokal, gap diisi di harga open (pesimistis). Untuk testnet/live wajib stop di sisi exchange (belum dibuat). |
| 10 | Zona waktu tidak ditetapkan. | Bug timestamp/hari rugi harian. | Semua timestamp = epoch ms UTC; "hari" = hari UTC. |
| 11 | Retensi & integritas audit log tidak ditentukan. | Log bisa diubah diam-diam. | JSONL dengan hash-chain + `verify_chain`; redaksi rahasia berdasarkan nama kunci. |
| 12 | Wallet scanner bukan bagian dari paket BTC. | Coupling lintas proyek dan risiko temuan scanner memicu trade tanpa kontrol. | Modul wallet dipisahkan ke paket `Altcoin_Wallet_Tracker_Separate.zip`; tidak diimpor oleh strategi/eksekusi BTC. Integrasi otomatis dilarang pada tahap ini. |
| 13 | Definisi "confidence terkalibrasi" tidak ada. | Angka menyesatkan. | `confidence=None` sampai ada kalibrasi nyata. |
| 14 | Tidak ada aturan sinyal basi/data basi di level nilai. | Order dari sinyal lama. | `max_data_age_seconds`, `max_signal_age_bars`; sinyal basi ditolak. |

## B. Jawaban atas pertanyaan audit (Bagian 11 dokumen) — berdasarkan kode ini

1. **Jalur strategy/AI → order tanpa risk engine?** Tidak ada: `ApprovedOrder` ditandatangani HMAC dengan kunci acak milik `RiskEngine`; adapter menolak order tanpa tanda tangan valid (`execution.py:submit_entry`, tes `test_forged_order_rejected`). Modul strategi tidak meng-import eksekusi/risk (tes AST `test_architecture.py`).
2. **Mode terpisah?** Config menolak TESTNET/LIVE; adapter simulasi hanya menerima BACKTEST/PAPER.
3. **Aman saat data basi/API timeout?** Validasi data gagal → tidak ada entri (`data.py`, `engine.py`).
4. **Retry menggandakan order?** `client_order_id` deterministik + adapter idempoten (tes `test_duplicate_is_idempotent`).
5. **Performa memasukkan biaya?** Ya: fee, spread, slippage, lot step, min notional (`execution.py`, `risk.py`).
6. **Look-ahead?** Indikator kausal, fill di open bar berikutnya, tes invarian pemotongan data. Survivorship bias: belum relevan (satu aset BTC), tapi tracker altcoin harus memperhatikannya.
7. **Tracker membedakan transfer dan trade?** Tidak termasuk paket BTC. Tes tracker berada di paket Altcoin Wallet Tracker terpisah.

## C. Celah yang masih TERBUKA (jangan dianggap selesai)

- Adapter testnet/live belum ada (G5/G6 jelas belum terpenuhi).
- Paper trading baru berupa `paper-step` (dipanggil berkala); belum ada uji berhari-hari.
- Data feed Binance (`fetch_binance_klines`) belum diuji terhadap jaringan sungguhan di lingkungan ini.
- Strategi EMA/RSI hanyalah **contoh kerangka**; tidak ada bukti profitabilitas.
- Model funding/margin/likuidasi untuk SHORT belum ada.
- Sumber data on-chain dan harga historis token untuk tracker belum ada.
