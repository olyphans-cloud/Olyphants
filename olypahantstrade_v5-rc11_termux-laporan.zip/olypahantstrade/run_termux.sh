#!/data/data/com.termux/files/usr/bin/sh
# Jalankan: sh run_termux.sh            (semua koin)   |   sh run_termux.sh BTCUSDT   (satu koin)
cd "$(dirname "$0")" || exit 1
SYM="${1:-BTCUSDT,ETHUSDT,BNBUSDT,SOLUSDT}"
python scripts/auto_report.py --symbols "$SYM"
